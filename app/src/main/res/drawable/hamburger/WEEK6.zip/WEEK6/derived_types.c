#include <mpi.h>
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <time.h>
#include <string.h>

// examples with derived types

void print_2D_array(int *a, int rows, int columns);

enum sizes {LEN = 30};

typedef struct {
    char name[LEN];
    int id;
    int numOfGrades;
    // char c;
 // double *grades;
}  Student;


void create_student_type(MPI_Datatype *student_type)
{
    int block_lengths[3] = {LEN, 1, 1};
    MPI_Aint displacements[3];
    MPI_Datatype types[3] = {MPI_CHAR, MPI_INT, MPI_INT};
    
    printf("offsets are: name: %zu, id: %zu, numOfGrades: %zu\n", 
              offsetof(Student, name), offsetof(Student, id), offsetof(Student, numOfGrades));
    printf("sizeof(Student) is %zu\n", sizeof(Student));

#if 0
    displacements[0] = offsetof(Student, name);
    displacements[1] = offsetof(Student, id);
    displacements[2] = offsetof(Student, numOfGrades);
#endif

    // this also works and is probably more portable:
    Student dummy_student;
    MPI_Aint base_address;
    MPI_Get_address(&dummy_student, &base_address);
    MPI_Get_address(&dummy_student.name[0], &displacements[0]);
    MPI_Get_address(&dummy_student.id, &displacements[1]);
    MPI_Get_address(&dummy_student.numOfGrades, &displacements[2]);

    for (int i = 0; i < 3; i++)
        displacements[i] = MPI_Aint_diff(displacements[i], base_address);
    
    MPI_Type_create_struct(3, block_lengths, displacements, types, student_type);
    MPI_Type_commit(student_type);
    
}

void print_student(Student *student)
{
    printf("Student name %s\n", student->name);
    printf("Student id %d\n", student->id);
    printf("Student numOfGrades %d\n", student->numOfGrades);
}

int main(int argc, char* argv[])
{
    MPI_Init(&argc,&argv);

    int myrank;

    MPI_Comm_rank(MPI_COMM_WORLD, &myrank);

    // example 1
    if (myrank == 0) {

        MPI_Datatype column_type;
        int stride = 4, block_length = 1;
        MPI_Type_vector(3, block_length, stride, MPI_INT, &column_type);
        MPI_Type_commit(&column_type);

        int myarray[3][4] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};

        print_2D_array((int *)myarray, 3, 4);
        
        printf("example 1: sending column 1 (second column)\n");
        int dest = 1, tag = 0;
        MPI_Send(&myarray[0][1], 1, column_type, dest, tag, MPI_COMM_WORLD);
    } else {
        int received_column[3];
        int source = 0, tag = 0;
        MPI_Recv(received_column, 3, MPI_INT, source, tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        printf("example 1: received column:  ");
        for (int i = 0; i < 3; i++)
            printf("%d ", received_column[i]);
        putchar('\n');
    }

    // example 2
    if (myrank == 0) {
        int darray[3][3] = { 1, 2, 3, 4, 5, 6, 7, 8, 9};
        print_2D_array((int *)darray, 3, 3);

        MPI_Datatype diagonal_type;
        int block_length = 1;
        int displacements[3] = { 0, 4, 8}; //  unit of diaplacement is one element (int in this case)
        MPI_Type_create_indexed_block(3, block_length, displacements, MPI_INT, &diagonal_type);
        MPI_Type_commit(&diagonal_type);

        int dest = 1, tag = 0;

        printf("example 2a: sending diagonal\n");
        MPI_Send(darray, 1, diagonal_type, dest, tag, MPI_COMM_WORLD);

        printf("example 2b: sending diagonal\n");
        MPI_Send(darray, 1, diagonal_type, dest, tag, MPI_COMM_WORLD);
    } else {
        // example 2a
        int received_diagonal[3];
        
        int source = 0, tag = 0;
        MPI_Recv(received_diagonal, 3, MPI_INT, source, tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        printf("example 2a: received diagonal:  ");
        for (int i = 0; i < 3; i++)
            printf("%d ", received_diagonal[i]);
        putchar('\n');

        // example 2b        
        MPI_Datatype reverse_diagonal_type;
        int block_length = 1;
        int displacements[3] = { 8, 4, 0}; // note the reverse order
        MPI_Type_create_indexed_block(3, block_length, displacements, MPI_INT, &reverse_diagonal_type);
        MPI_Type_commit(&reverse_diagonal_type);

        int rarray[3][3] = {0};  // initialize all elements to 0 
        MPI_Recv(rarray, 1, reverse_diagonal_type, source, tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        printf("example 2b: after receiving diagonal, array with reversed diagonal:\n");
        print_2D_array((int *)rarray, 3, 3);
        putchar('\n');
    } // rank not 0

    // example 3
    // both processes use student_type and three_students_type in example 3:
    MPI_Datatype student_type;
    create_student_type(&student_type);

    MPI_Datatype three_students_type;
    MPI_Type_contiguous(3, student_type, &three_students_type);
    MPI_Type_commit(&three_students_type);
    
    if (myrank == 0) {
        Student students[3] = { {"John", 1, 3}, {"Mary", 2, 5}, {"Donald", 3, 7}};

        int dest = 1, tag = 0;
        // same as MPI_Send(students, 3, student_type, dest, tag, MPI_COMM_WORLD);
        MPI_Send(students, 1, three_students_type, dest, tag, MPI_COMM_WORLD);
    } else {
        Student received_students[3];
        int source = 0, tag = 0;
        // same as MPI_Recv(received_students, 3, student_type, source, tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(received_students, 1, three_students_type, source, tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        for(int i = 0; i < 3; i++) {
            print_student(received_students+i);
        }
    } // not rank 0

    MPI_Finalize();
    return 0;
}

// print two dimensional array. Note that a points to the first 
// element of a two dimensional array.
void print_2D_array(int *a, int rows, int columns) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < columns; j++)
            printf("%d ", a[i * columns + j]);
        putchar('\n');
    }
}