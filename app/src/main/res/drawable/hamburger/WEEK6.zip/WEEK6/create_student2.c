#include <mpi.h>
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <time.h>
#include <string.h>
enum sizes {LEN = 30};

typedef struct {
 char name[LEN];
 int id;
 int numOfGrades;
 char c;
 // double *grades;
}  Student;


void create_student_type(MPI_Datatype *student_type)
{
    int block_lengths[3] = {LEN, 1, 1};
    MPI_Aint displacements[3];
    MPI_Datatype types[3] = {MPI_CHAR, MPI_INT, MPI_INT};
    
    printf("offsets are: name: %zu, id: %zu, numOfGrades: %zu\n", 
              offsetof(Student, name), offsetof(Student, id), offsetof(Student, numOfGrades));
    printf("sizeof(Student) is %zu\n", sizeof(Student));

#if 0
    displacements[0] = offsetof(Student, name);
    displacements[1] = offsetof(Student, id);
    displacements[2] = offsetof(Student, numOfGrades);
#endif

    // this also works and is probably more portable:
    Student dummy_student;
    MPI_Aint base_address;
    MPI_Get_address(&dummy_student, &base_address);
    MPI_Get_address(&dummy_student.name[0], &displacements[0]);
    MPI_Get_address(&dummy_student.id, &displacements[1]);
    MPI_Get_address(&dummy_student.numOfGrades, &displacements[2]);

    for (int i = 0; i < 3; i++)
        displacements[i] = MPI_Aint_diff(displacements[i], base_address);
    
    MPI_Type_create_struct(3, block_lengths, displacements, types, student_type);
    MPI_Type_commit(student_type);
    
}

void print_student(Student *student)
{
    printf("Student name %s\n", student->name);
    printf("Student id %d\n", student->id);
    printf("Student numOfGrades %d\n", student->numOfGrades);
}

int main(int argc, char* argv[])
{
    MPI_Init(&argc,&argv);

    MPI_Datatype student_type;
    int myrank;

    create_student_type(&student_type);
   
    MPI_Comm_rank(MPI_COMM_WORLD, &myrank);

    if (myrank == 0) {
        Student student = { "John", 15, 5};
        print_student(&student);
        int dest = 1, tag = 0;
        MPI_Send(&student, 1, student_type, dest, tag, MPI_COMM_WORLD);
    } else {
        Student s;
        int source = 0, tag = 0;
        MPI_Recv(&s, 1, student_type, source, tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        print_student(&s);
    }

    MPI_Finalize();
    return 0;
}