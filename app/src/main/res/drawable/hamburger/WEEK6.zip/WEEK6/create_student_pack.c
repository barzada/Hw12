#include <mpi.h>
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <time.h>
#include <string.h>
enum sizes {LEN = 30, BUFFER_SIZE = 1024};

typedef struct {
    char name[LEN];
    int id;
    int numOfGrades;
    double *grades;
}  Student;


void create_student_type(MPI_Datatype *student_type)
{
    int block_lengths[3] = {LEN,1,1};
    MPI_Aint displacements[3];
    MPI_Datatype types[3] = {MPI_CHAR, MPI_INT, MPI_INT};
    
    printf("offsets are: name: %zu, id: %zu, numOfGrades: %zu\n", 
              offsetof(Student, name), offsetof(Student, id), offsetof(Student, numOfGrades));
    printf("sizeof(Student) is %zu\n", sizeof(Student));
    printf("sizeof(double *) is %zu\n", sizeof(double *));

    displacements[0] = offsetof(Student, name);
    displacements[1] = offsetof(Student, id);
    displacements[2] = offsetof(Student, numOfGrades);

   // displacement[3] = offsetof(Student,grades);

#if 0
    // this also works and is probably more portable:
    Student dummy_student;
    MPI_Aint base_address;
    MPI_Get_address(&dummy_student, &base_address);
    MPI_Get_address(&dummy_student.name[0], &displacements[0]);
    MPI_Get_address(&dummy_student.id], &displacements[1]);
    MPI_Get_address(&dummy_student.numOfGrades, &displacements[2]);

    for (int i = 0; i < 3; i++)
        displacements[i] = MPI_Aint_diff(displacements[i], base_address);
#endif
    
    MPI_Type_create_struct(3, block_lengths, displacements, types, student_type);
    MPI_Type_commit(student_type);
    
}

void print_student(Student *student)
{
    printf("Student name %s\n", student->name);
    printf("Student id %d\n", student->id);
    printf("Student numOfGrades %d\n", student->numOfGrades);

    printf("Grades:\n");

    for (int i = 0; i < student->numOfGrades; i++)
    {
        printf("%.1f\n",student->grades[i]);
    }
  
}

int main(int argc, char* argv[])
{
    MPI_Init(&argc,&argv);

    MPI_Datatype student_type;
    int myrank;

    create_student_type(&student_type);
   
    MPI_Comm_rank(MPI_COMM_WORLD, &myrank);

    char buff[BUFFER_SIZE];
    int position= 0;
    if(myrank == 0)
    {
        Student student = { "John", 15, 5, (double *)0};
            
        student.grades = (double*)malloc(sizeof(double)*student.numOfGrades);
        for (int i = 0; i < student.numOfGrades; i++) {
            student.grades[i] = rand() % 51 + 50;
        }
    
        print_student(&student);
    
      	int position = 0;
        MPI_Pack(&student, 1, student_type, buff, BUFFER_SIZE, &position, MPI_COMM_WORLD);
        MPI_Pack(student.grades, student.numOfGrades, MPI_DOUBLE, 
                 buff, BUFFER_SIZE, &position, MPI_COMM_WORLD);
        MPI_Send(buff, position, MPI_PACKED, 1, 0, MPI_COMM_WORLD);
        free(student.grades);
    }
    else
    {
        MPI_Recv(buff, BUFFER_SIZE, MPI_PACKED, 0 ,0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        
        Student received_student;

		int position = 0;
        MPI_Unpack(buff, BUFFER_SIZE, &position, &received_student, 1, student_type, MPI_COMM_WORLD);
        received_student.grades = (double*) malloc(sizeof(double)*received_student.numOfGrades);
        MPI_Unpack(buff, BUFFER_SIZE, &position,
                   received_student.grades, received_student.numOfGrades, MPI_DOUBLE, MPI_COMM_WORLD);
        
        print_student(&received_student);
        free(received_student.grades);
    }
    

    MPI_Finalize();
    return 0;
}