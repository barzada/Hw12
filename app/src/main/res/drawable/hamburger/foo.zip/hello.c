#include <stdio.h>

int main(int argc, char**argv) {
   printf("hello world. %s. Bye\n", argv[1]); 
}


