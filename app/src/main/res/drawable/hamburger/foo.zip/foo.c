#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main (int argc, char **argv) {
    int pipefd[2];

    pipe(pipefd);
    

    pid_t pid = fork();
    if (pid == 0) {
        char buffer[100] = { 0 };
        printf("child with pid = %d\n", getpid());
        read (pipefd[0], buffer, 5);
        buffer[5] = '\0';
        printf("child read from pipe: %s\n", buffer);
       //  execl("hello", "hello", "today is Monday\n", (char*) NULL);
    }
    else {
        write(pipefd[1], "abcde", 5);
        printf("parent with pid = %d, child has pid %d\n", getpid(), pid);
    }
    return 0;
}