#include <mpi.h>
#include <stdio.h>
#include <omp.h>
#include <stdlib.h>

#define PART 100

/*
    Simple MPI+OpenMP Integration example
    Initially the array of size 2*PART is known for the process 0.
    It sends (using MPI) half of the array to process 1.
    Each of the two processes finds the maximum element in its
	half of the array using OpenMP.
    Finally the global maximum is found using MPI reduce.

    Note that in this simple program - MPI routines are not called
    inside the OpenMP parallel region. 	
*/

int findmax(int *array, int size) {
	int max = array[0];	
    for (int i = 1; i < size; i++)       
        if (array[i] > max)
           max = array[i];
    return max;	   
}

void populate_array(int *array, int size) {
    for (int i = 0; i < size; i++)
        array[i] = i;
	array[size/2] = 2*size+17; // this is the maximum
	array[0] = 2*size+1; // just an example
}	

int main(int argc, char *argv[]) {
    int size, rank;
    int *data;
    MPI_Status  status;

    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    if (size != 2) {
       fprintf(stderr, "Run the example with two processes only\n");
       MPI_Abort(MPI_COMM_WORLD, __LINE__);
    }
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    
    // Divide the tasks between both processes
    if (rank == 0) {
       // Allocate memory for the whole array and send half of the array to other process
       if ((data = (int *) malloc(2*PART*sizeof(int))) == NULL)
          MPI_Abort(MPI_COMM_WORLD, __LINE__);
	  
	   populate_array(data, 2*PART);
       MPI_Send(data + PART, PART, MPI_INT, 1, 0, MPI_COMM_WORLD);
    } else {
       // Allocate memory and receive a half of array from other process
       if ((data = (int *) malloc(PART*sizeof(int))) == NULL)
          MPI_Abort(MPI_COMM_WORLD, __LINE__);
       MPI_Recv(data, PART, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
    }
  
    // On each process - find the maximum of its part using openMP
   int mymax = data[0];	
#pragma omp parallel for reduction(max:mymax) default(none) shared(data)
    for (int i = 1; i < PART; i++)       
        if (data[i] > mymax)
           mymax = data[i];			
	
    int global_max; //used in rank 0
	
	int root = 0;
    MPI_Reduce(&mymax, &global_max, 1, MPI_INT, MPI_MAX, root, MPI_COMM_WORLD);

    if (rank == 0) {
        printf("parallel max is %d\n", global_max);
    
        global_max = findmax(data, 2*PART);
   
        printf("sequential max is %d\n", global_max);
    }
       
    MPI_Finalize();

    return 0;
}


