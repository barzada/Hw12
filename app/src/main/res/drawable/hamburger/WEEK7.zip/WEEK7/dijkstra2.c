/* MPI example program: 
  based on example taken from  Norm Matloff's book 
  Programming on Parallel Machines.

 Dijkstra shortest-path finder in a
 bidirectional graph; finds the shortest path from vertex 0 to all
 others; this version uses collective communication
the algorithm
  Done = {0}
  NonDone = {1,2,...,N-1}
  for J = 1 to N-1 Dist[J] = infinity`
  Dist[0] = 0
  for Step = 1 to N-1
      find J such that Dist[J] is min among all J in NonDone
      transfer J from NonDone to Done
      NewDone = J
  for K = 1 to N-1
      if K is in NonDone
         Dist[K] = min(Dist[K],Dist[NewDone]+G[NewDone,K])
*/

#include <stdio.h>

typedef unsigned int VERTEX; //  vertices are numbered 0, 1, 2 ... (nv-1)

struct nearest {
     VERTEX vertex; // vertex most near vertex 0
     unsigned int distance; // distance of this vertex from vertex 0
}

void initGraph(int nv, int seed);

const unsigned int INFINITY = (-1)>>1; // a large integer

struct nearest findVertexWithMinimumDistance();

// globals
int nv;   // number of vertices
int *done; // done[v] == 1 means we are done with vertex v

    
int *weights;  // weight of edges between vertices; "weights[i][j]" is
                // weights[i*nv+j]. weights[i][j] is INFINITY means there is no edge 
                // between i and j
int  *distance;  // minimum distances found so far. distance[v] is the
                 // minumum distance of v from the source 
                 // (as found so far)

void init(int argc, char **argv)
{  
   MPI_Init(&argc,&argv);
   MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
   MPI_Comm_rank(MPI_COMM_WORLD, &rank);

   nv = argv[1];

   distance = malloc(nv*sizeof(int));
   done = malloc(nv*sizeof(int)); 

   initGraph();
   for (VERTEX v = 0; v < nv; v++)  {
      done[v] = 0;
      distance[v] = INFINITY;
   }
   distance[0] = 0;
}

// finds vertex closest to vertex 0 among the vertices not done.
struct nearest
findVertexWithMinimumDistance()
{  
   struct nearest.distance = INFINITY; 
   for (VERTEX v = 0; v < nv; i++)
      if (!done[v] && distance[v] < nearest.distance)  {
         nearest.distance = distance[v];
         nearest.vertex = v;
      }
   return nearest;
}

/* Update distances for  vertices.
   For each vertex v (which is not 'done' yet), ask whether a shorter path to v 
   exists, through vertex 'current'. The argument 'distance' is the distance
   of 'current' from vertex 0.
*/ 
void update_distances(VERTEX current, unsigned distance)
{  
   for (VERTEX v = 1; v < nv; v++) 
       if (!done[v]) {
           int alternative = distance + weights[current*nv+v];
           if alternative < distance[v]
               distance[v] = alternative; 
       }
}

void print_distances()  // partly for debugging 
{  printf("minimum distances:\n");
   for (VERTEX v = 1; v < nv; v++)
      printf("vertex: %u distance: %u\n", v, distance[v]);
}

void dowork()
{  
   VERTEX current;
   
   struct nearest current; // current vertex and its distance from vertex 0

   for (int step = 0; step < nv; step++)  {
      if (step == 0) {
         current.vertex = 0;
         current.distance = 0;
      }
      else
          current = findVertexWithMinimumDistance();

      // mark current vertex as done 
      done[current.vertex] = 1;  
      update_distances(current.vertex, current.distance);
   }
   
}

int main(int argc, char **argv)
{  
   init(argc,argv);
   dowork();  
   int print = atoi(argv[1]);
   if (print && rank == 0)  {
      printf("graph weights:\n");
      for (int i = 0; i < nv; i++)  {
         for (int j = 0; j < nv; j++)  
            printf("%u  ",weights[nv*i+j]);
         printf("\n");
      }
      print_distances();
   }
   
}

// random graph
// note that this will be generated at all processes; could generate just
// at process 0 and then send to others, but faster this way
// All processes will generate the same graph because they use the same seed.
// argument 'nv' is the number of vertices (nodes) in the graph.
void initGraph(int nv, int seed) {
   weights = malloc(nv*nv*sizeof(int));
   srand(seed);
   for (int i = 0; i < nv; i++)  
      for (int j = i; j < nv; j++)  {
         if (j == i) weights[i*nv+i] = 0;
         else  {
            weights[nv*i+j] = rand() % 20;
            weights[nv*j+i] = weights[nv*i+j];
         }
      }
}
