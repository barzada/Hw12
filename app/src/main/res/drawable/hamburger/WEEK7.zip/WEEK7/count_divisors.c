#include <omp.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#define MAX_NUMBER 100
#define SIZE 50000

void generateNumbers(int* arr, int size);

void countDivisors(int *arr, int size);
void countSequentialDivisors(int *arr, int size);

int main(int argc, char* argv[])
{
	int arr[SIZE];

	generateNumbers(arr, SIZE);

    double t0 = omp_get_wtime();
	
	countDivisors(arr, SIZE);

	double t1 = omp_get_wtime();


	printf("Time(parallel version): %lf seconds\n", t1 - t0); // note: we also 
	   // timed the printing of the results which is not good ...

    t0 = omp_get_wtime();
	
	countSequentialDivisors(arr, SIZE);

	t1 = omp_get_wtime();


	printf("Time(sequential version): %lf seconds\n", t1 - t0);

	return 0;
}


//  count number of elements in array 'arr' divisable by 2 3, ... 10
void countDivisors(int* arr, int size)
{
	int counters[11] = { 0 };
	#pragma omp parallel for default(none) shared(counters, arr, size) 
	    for (int d = 2; d < 11; d++)
		    for(int i = 0; i < size; i++)
                if (arr[i] % d == 0)
			        counters[d]++; // no race condition: each thread will
					          // access distinct entries of 'counters'

 	for (int d = 2; d < 11; d++)
	    printf("(parallel) count of numbers divisable by %d: %d\n", d, counters[d]);
	    
}

void countSequentialDivisors(int* arr, int size)
{
	int counters[11] = { 0 };
	    for (int d = 2; d < 11; d++)
		    for(int i = 0; i < size; i++)
                if (arr[i] % d == 0)
			        counters[d]++; 

 	for (int d = 2; d < 11; d++)
	    printf("sequential count of numbers divisable by %d: %d\n", d, counters[d]);
	    
}

void generateNumbers(int* arr, int size)
{
#pragma omp parallel
	{
		int threadId = omp_get_thread_num();
		int numOfThreads = omp_get_num_threads();

        unsigned int seed = time(NULL) + threadId;
		// srand(time(NULL) + threadId); and then use rand(). But this
		// is not reentrant. rand_r(() is reentrant)

		for (int i = threadId; i < size; i += numOfThreads)
		{
			arr[i] = rand_r(&seed) % MAX_NUMBER; 
		}
	}
}
